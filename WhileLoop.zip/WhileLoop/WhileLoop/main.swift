//
//  main.swift
//  WhileLoop
//
//  Created by anil kumar giri on 22/02/16.
//  Copyright © 2016 AKG. All rights reserved.
//

import Foundation
// while loop
var i=1
while i < 10 {
    print(i)
    i++
}

// repeat-while 
var k=0
repeat {
print(k)
    k++
} while k < 10




